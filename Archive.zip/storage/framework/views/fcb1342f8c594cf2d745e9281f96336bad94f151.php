<div class="modal-body">
    <input type="hidden" name="_method" value="PUT">
    <input type="hidden" name="update_id" value="<?php echo e($nft->id); ?>">
    <div class="form-group">
        <label for="name" class="col-form-label">Name:</label>
        <input type="text" data-validation="required" name="name" class="form-control" id="name"
            value="<?php echo e($nft->name); ?>">
    </div>
    <div class="form-group">
        <label for="category" class="col-form-label">Select Category:</label>
        <select name="category_id" data-validation="required" class="form-select shadow-none select2-hidden-accessible"
            style="width: 100%; height: 36px">
            <option value="">Select</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($nft->category_id == $category->id ? 'selected' : ''); ?>>
                    <?php echo e($category->title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="image" class="col-form-label">Image:</label>
        <input type="file" data-validation="mime" data-validation-allowing="jpg, png, jpeg , gif" name="image"
            class="form-control" id="image">
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary submitBtn">Submit</button>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ricesnetwork/resources/views/admin/nft/edit.blade.php ENDPATH**/ ?>