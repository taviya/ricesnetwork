<footer class="footer text-center">
    All Rights Reserved by <a href="#">Rices Network</a>.
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ricesnetwork/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>