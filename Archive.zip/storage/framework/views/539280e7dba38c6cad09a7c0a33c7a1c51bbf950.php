<?php $__env->startSection('content'); ?>
<div class="front-page-container container-fluid mt-5">
    <h1 class="mb-3"><?php echo e(__('Login')); ?></h1>
    <div class="mx-auto my-auto main-card p-5">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email"><?php echo e(__('Email Address')); ?></label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php $__errorArgs = ['error_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="password"><?php echo e(__('Password')); ?></label>
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="primary-button mt-4 w-100 mb-4">
                <span class="btn__text">Sign In</span>
            </button>

            <div class="seperator"><b>OR</b></div>
            <div class="d-grid text-center">
                <div class="dt_social_login dt_social_login_btn">
                    <button id="connectButton" type="button" class="btn text-white text-center btn-lg fw-bold mb-2 btn-main w-100">
                        <img src="<?php echo e(asset('public/assets/upload/metamask.png')); ?>" class="w-10" height="35px" width="35px">

                        <span class="w-5/6">Login With Metamask</span>
                    </button>
                </div>
            </div>

            <div class="links">
                <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('Forgot Your Password?')); ?>

                </a>
                <?php endif; ?>
                <a href="<?php echo e(route('register')); ?>">Do not have an account?</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>



<script>
    function sendLoginRequest(ethAddress, message1, signature, type = 1) {
        $.ajax({
            url: "<?php echo e(route('authenticate')); ?>",
            type: 'POST',
            async: false,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            data: {
                'ethAddress': ethAddress,
                'message': message1,
                'signature': signature,
            },
            success: (xhr, data) => {
                window.location = "<?php echo e(route('home')); ?>";
            },
            error: (xhr, data) => {
                message(xhr.responseJSON.message, 'danger');
            }
        });
    }
</script>
<?php echo $__env->make('user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ricesnetwork/resources/views/auth/login.blade.php ENDPATH**/ ?>