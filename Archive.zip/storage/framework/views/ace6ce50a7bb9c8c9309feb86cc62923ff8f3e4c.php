


<aside class="left-sidebar" data-sidebarbg="skin5">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="pt-4">
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link <?php if(\Request::route()->getName() == 'admin'): ?> active <?php endif; ?>"
                        href="<?php echo e(route('admin')); ?>" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                            class="hide-menu">Dashboard</span></a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link <?php if(\Request::route()->getName() == 'category'): ?> active <?php endif; ?>"
                        href="<?php echo e(route('category.index')); ?>" aria-expanded="false"><i
                            class="mdi mdi-border-inside"></i><span class="hide-menu">Cayegory</span></a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link <?php if(\Request::route()->getName() == 'nft'): ?> active <?php endif; ?>"
                        href="<?php echo e(route('nft.index')); ?>" aria-expanded="false"><i class="mdi mdi-arrow-all"></i><span
                            class="hide-menu">Nft</span></a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ricesnetwork/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>