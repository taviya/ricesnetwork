<footer class="footer text-center">
    All Rights Reserved by <a href="#">Rices Network</a>.
</footer>
